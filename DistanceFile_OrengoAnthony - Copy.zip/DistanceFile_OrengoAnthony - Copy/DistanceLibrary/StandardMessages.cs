﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DistanceLibrary
{
    public class StandardMessages
    {
        //Display program instructions
        public static string DisplayWelcomeMessage()
        {
            return "*******************************************\n" +
                   "* Welcome to the Travel Distance Program  *\n" +
                   "*******************************************" +
                   "\n\n\nPress Enter...";
        }
        //Display program instructions
        public static string DisplayProgramInstructions()
        {
            return "*******************************************\n" +
                   "*  Travel Distance Program Instructions   *\n" +
                   "*******************************************\n" +
                   "\nThe Travel Distance Program allows the user to input specific travel data (Speed/Time), " +
                   "\nand then calculates the total distance traveled. The user must follow the steps below in order" +
                   "\nto save the outputted data to a document.\n\n" +
                   "Step1: Create document or use existing document.\n***" + @"Note: All documents will be located in ConsoleUI\bin\Debug\DistanceDocuments" +
                   "\n\nStep2: Enter travel data (Speed/Time)" +
                   "\n\nStep3: Calculate Distance/Write to Document." +
                   "\n\n" +
                   "****Take note that when a document is created, that will be the document used for writing to, unless" +
                   "\nthe user creates or chooses a different document to write to. When in doubt select 4 to verify " +
                   "\nthe current document being used." +
                   "\n\nPress Enter to continue....";
        }
        //Display main menu
        public static string DisplayMainMenu()
        {
            return "*******************************************\n" +
                   "*         Travel Distance Program         *\n" +
                   "*******************************************\n" +
                   "1. Create/Choose Text Document\n" +
                   "2. Enter Travel Data\n" +
                   "3. Calculate Distance/Write to Document\n" +
                   "4. Verify Current Document\n" +
                   "Esc. Exit\n" +
                   "\nMake a selection";
        }
        //Display main menu
        public static string DisplayDocumentMenu()
        {
            return "*************************\n" +
                   "*   Document Selection  *\n" +
                   "*************************\n" +
                   "1. Create Document\n" +
                   "2. Use Existing Document\n" +
                   "Esc. Return to Main Menu" +
                   "\n\nMake a selection";
        }
        //Display title to user
        public static string DisplayDocumentCreationTitle()
        {
            return "*************************\n" +
                   "*    Document Creation   *\n" +
                   "*************************";

            
        }
        //Display title to user
        public static string DisplayDocumentNameTitle()
        {
            return "*************************\n" +
                   "*  Input Document Name  *\n" +
                   "*************************";
        }
        //Display title to user
        public static string DisplayWriteToDocumentTitle()
        {
            return "*************************\n" +
                   "*   Write to Document   *\n" +
                   "*************************";
        }
            //Display instructions to user
            public static string DisplayDocumentInstructions()
        {
            return "*************************\n" +
                   "*    Create Document    *\n" +
                   "*************************" +
                   "\n" +
                   "1. Name your document in relation to your project.\n" +
                   "2. Capitalize each word you use.\n" +
                   "3. Do not leave spaces between each word." +
                   " Use an underscore to separate words.\n" +
                   "\n* Although the above will not inhibit you from creating a document, it is strongly\n" +
                   "encouraged you use proper document naming techniques.\n" +
                   "\n\n" +
                   "* You will not be able to create a document if your file name includes the following:\n\n" +
                   "*****************************\n" +
                   ".txt\n" +
                   "< (less than)\n" +
                   "> (greater than)\n" +
                   ": (colon)\n" +
                  @""" (double quote)" +
                   "\n/ (forward slash)\n" +
                  @"\ (backslash)" +
                   "\n| (vertical bar or pipe)\n" +
                   "? (question mark)\n" +
                   "*(asterisk)\n" +
                   "*****************************\n" +
                   "Press Enter...";            
        }
        //Display title to user
        public static string DisplayCurrentDocumentTitle()
        {
            return "*************************\n" +
                   "*    Current Document   *\n" +
                   "*************************";

        }
        //Display title to user
        public static string DisplayCalculatorTitle()
        {
            return "*************************\n" +
                   "*  Distance Calculator  *\n" +
                   "*************************";

        }
        public static string DisplayFinalResultTitle()
        {
            return "*************************\n" +
                   "*  Distance Traveled  *\n" +
                   "*************************";

        }
        //Display enter time to user
        public static string DisplayEnterTime()
        {
            return "Enter hours traveled--> ";

        }
        //Display enter vehicle speed to user
        public static string DisplayEnterVehicleSpeed()
        {
            return "Enter Vehicle speed--> ";
        }
        //Display press enter to user
        public static string DisplayPressEnter()
        {
            return "\n\nPress Enter...";
        }
        //Display invalid option to user
        public static string DisplayInvalidOption()
        {
            return "\nNot a valid option! Press enter and try again!";
        }
    }
}
